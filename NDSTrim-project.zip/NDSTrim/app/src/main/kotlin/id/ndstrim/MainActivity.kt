package id.ndstrim

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class MainActivity : Activity() {

    private lateinit var pickButton: Button
    private lateinit var logView: TextView
    private val reqPick = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "NDS Trim"
            textSize = 26f
            setTypeface(typeface, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "Pangkas ROM Nintendo DS. ROM asli tidak diubah; hasil disimpan " +
                "sebagai nama_trimmed.nds di folder Download."
            textSize = 15f
            setPadding(0, pad / 3, 0, pad)
        })
        pickButton = Button(this).apply {
            text = "Pilih ROM .nds"
            setOnClickListener { pickFiles() }
        }
        root.addView(pickButton)
        logView = TextView(this).apply {
            textSize = 14f
            setPadding(0, pad, 0, 0)
            gravity = Gravity.START
        }
        root.addView(logView)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, reqPick)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK || data == null) return

        val uris = mutableListOf<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }

        pickButton.isEnabled = false
        logView.text = ""
        Thread {
            for (u in uris) {
                val msg = try { process(u) } catch (e: Exception) { "Gagal: ${e.message}" }
                say(msg)
            }
            runOnUiThread { pickButton.isEnabled = true }
        }.start()
    }

    private fun say(line: String) = runOnUiThread { logView.append(line + "\n\n") }

    private fun mb(n: Long) = String.format("%.2f MB", n / 1048576.0)

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return "rom.nds"
    }

    private fun process(uri: Uri): String {
        val name = displayName(uri)
        val pfd = contentResolver.openFileDescriptor(uri, "r")
            ?: return "$name: tidak bisa dibuka."
        pfd.use {
            val size = it.statSize
            FileInputStream(it.fileDescriptor).use { fis ->
                val used = trimmedSize(fis, size)
                    ?: return "$name: bukan ROM NDS yang valid."
                if (used >= size) return "$name: sudah ter-trim (${mb(size)})."

                val outName = name.substringBeforeLast('.', name) + "_trimmed.nds"
                copyToDownloads(fis, used, outName)
                return "$name: ${mb(size)} -> ${mb(used)} (hemat ${mb(size - used)})\n" +
                    "Disimpan: Download/$outName"
            }
        }
    }

    /** Hitung ukuran ROM yang terpakai dari header NDS. null jika bukan NDS. */
    private fun trimmedSize(fis: FileInputStream, fileSize: Long): Long? {
        val ch = fis.channel
        ch.position(0)
        val head = ByteBuffer.allocate(0x240).order(ByteOrder.LITTLE_ENDIAN)
        while (head.hasRemaining()) if (ch.read(head) < 0) break
        if (head.position() < 0x200) return null
        head.flip()

        var used = head.getInt(0x80).toLong() and 0xFFFFFFFFL
        val unit = head.get(0x12).toInt()
        if ((unit and 2) != 0 && head.limit() >= 0x214) {
            val dsi = head.getInt(0x210).toLong() and 0xFFFFFFFFL
            if (dsi > used) used = dsi
        }
        // Tanda tangan RSA 0x88 byte setelah data ("ac")
        if (used > 0 && used + 2 <= fileSize) {
            val sig = ByteBuffer.allocate(2)
            ch.position(used)
            ch.read(sig)
            if (sig.get(0).toInt() == 0x61 && sig.get(1).toInt() == 0x63) used += 0x88
        }
        if (used <= 0x200 || used > fileSize) used = fileSize
        return used
    }

    private fun copyToDownloads(fis: FileInputStream, count: Long, outName: String) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, outName)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val target = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("tidak bisa membuat file di Download")
        try {
            fis.channel.position(0)
            contentResolver.openOutputStream(target)!!.use { out ->
                val buf = ByteArray(1 shl 20)
                var left = count
                while (left > 0) {
                    val n = fis.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) break
                    out.write(buf, 0, n)
                    left -= n
                }
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            contentResolver.update(target, done, null, null)
        } catch (e: Exception) {
            contentResolver.delete(target, null, null)
            throw e
        }
    }
}
