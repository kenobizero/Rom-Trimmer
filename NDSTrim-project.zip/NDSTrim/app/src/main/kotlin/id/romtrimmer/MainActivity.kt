package id.romtrimmer

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

/** Dilempar saat file sebaiknya tidak dipangkas; pesannya ditampilkan ke pengguna. */
private class Skip(msg: String) : Exception(msg)

private enum class Kind { OK, INFO, ERR }

private class Outcome(
    val kind: Kind,
    val title: String,
    val body: String,
    val saved: String? = null,
    val note: String? = null,
    val bytes: Long = 0L
)

class MainActivity : Activity() {

    private lateinit var pickButton: Button
    private lateinit var statusView: TextView
    private lateinit var resultsBox: LinearLayout
    private lateinit var emptyView: TextView
    private lateinit var overwriteSwitch: Switch
    private lateinit var gbaSwitch: Switch

    private val reqPick = 1
    private val supported = setOf("3ds", "cci", "nds", "dsi", "xci", "gba")
    private val slowScan = setOf("3ds", "cci", "xci", "gba")
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    // ---------- helper tampilan ----------

    private fun dp(n: Int) = (n * resources.displayMetrics.density + 0.5f).toInt()

    private fun col(id: Int) = getColor(id)

    private fun shape(fill: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun tv(text: String, size: Float, color: Int, medium: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            if (medium) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

    private fun lp(topDp: Int = 0) = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(topDp) }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(col(R.color.surface), 16, col(R.color.line))
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    private fun styleSwitch(sw: Switch, checked: Boolean) {
        sw.isChecked = checked
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(col(R.color.accent), col(R.color.muted)))
        sw.trackTintList = ColorStateList(states, intArrayOf(col(R.color.accent_soft), col(R.color.line)))
    }

    private fun settingRow(title: String, sub: String, sw: Switch): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(title, 15f, col(R.color.ink), true))
        texts.addView(tv(sub, 13f, col(R.color.muted)), lp(2))
        row.addView(texts, LinearLayout.LayoutParams(0, WRAP, 1f).apply { rightMargin = dp(12) })
        row.addView(sw)
        return row
    }

    // ---------- layar ----------

    @Suppress("DEPRECATION")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
        if (!night) {
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        val ink = col(R.color.ink)
        val muted = col(R.color.muted)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }

        // Header: logo + nama
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val logoBox = FrameLayout(this).apply {
            background = shape(col(R.color.logo_bg), 16)
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        val logo = ImageView(this).apply { setImageResource(R.drawable.ic_launcher_foreground) }
        logoBox.addView(logo, FrameLayout.LayoutParams(dp(108), dp(108), Gravity.CENTER))
        header.addView(logoBox, LinearLayout.LayoutParams(dp(56), dp(56)))
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), 0, 0, 0)
        }
        titles.addView(tv("ROM Trimmer", 26f, ink, true).apply { letterSpacing = -0.02f })
        titles.addView(tv("Hemat ruang, isi game tetap utuh", 14f, muted))
        header.addView(titles)
        root.addView(header, lp())

        root.addView(
            tv(
                "Pangkas padding kosong di ujung ROM untuk menghemat penyimpanan " +
                    "tanpa mengubah isi game.",
                15f, muted
            ).apply { setLineSpacing(0f, 1.15f) },
            lp(18)
        )

        // Tombol utama
        pickButton = Button(this).apply {
            text = "Pilih ROM"
            isAllCaps = false
            textSize = 17f
            setTextColor(col(R.color.on_accent))
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = shape(col(R.color.accent), 16)
            stateListAnimator = null
            minHeight = dp(56)
            minimumHeight = dp(56)
            setOnClickListener { pickFiles() }
        }
        root.addView(pickButton, lp(20))

        // Pengaturan
        overwriteSwitch = Switch(this)
        gbaSwitch = Switch(this)
        styleSwitch(overwriteSwitch, true)
        styleSwitch(gbaSwitch, false)
        val settings = card()
        settings.addView(tv("Pengaturan", 13f, muted, true))
        settings.addView(
            settingRow(
                "Timpa ROM asli",
                "Tanpa salinan, hemat memori. Tidak bisa dibatalkan.",
                overwriteSwitch
            ),
            lp(12)
        )
        settings.addView(
            View(this).apply { setBackgroundColor(col(R.color.line)) },
            LinearLayout.LayoutParams(MATCH, dp(1)).apply { topMargin = dp(12) }
        )
        settings.addView(
            settingRow(
                "Izinkan trim GBA",
                "Menghapus byte 0xFF di ujung file. Tes dulu satu game.",
                gbaSwitch
            ),
            lp(12)
        )
        root.addView(settings, lp(16))

        // Format yang didukung
        val formats = card()
        formats.addView(tv("Format yang didukung", 13f, muted, true))
        val grid = GridLayout(this).apply { columnCount = 3 }
        listOf("3DS", "NDS", "DSi", "GBA", "XCI").forEach { label ->
            val chip = tv(label, 14f, col(R.color.accent), true).apply {
                gravity = Gravity.CENTER
                background = shape(col(R.color.accent_soft), 20)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            val glp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            )
            glp.width = 0
            glp.setMargins(0, 0, dp(8), dp(8))
            grid.addView(chip, glp)
        }
        formats.addView(grid, lp(10))
        formats.addView(tv(".3ds  .cci  .nds  .dsi  .gba  .xci", 13f, muted), lp(2))
        root.addView(formats, lp(12))

        // Hasil
        root.addView(tv("Hasil", 18f, ink, true), lp(24))
        statusView = tv("", 13f, muted).apply { visibility = View.GONE }
        root.addView(statusView, lp(6))
        resultsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resultsBox, lp())
        emptyView = tv("Belum ada ROM yang diproses. Ketuk \"Pilih ROM\" untuk mulai.", 14f, muted)
        root.addView(emptyView, lp(8))

        root.addView(
            tv("Tidak berafiliasi dengan Nintendo.", 12f, muted).apply { gravity = Gravity.CENTER },
            lp(28)
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(col(R.color.bg))
            isFillViewport = true
            addView(root)
        })
    }

    private fun setBusy(busy: Boolean) {
        pickButton.isEnabled = !busy
        pickButton.alpha = if (busy) 0.5f else 1f
        pickButton.text = if (busy) "Memproses…" else "Pilih ROM"
    }

    private fun setStatus(text: String) = runOnUiThread {
        statusView.text = text
        statusView.visibility = View.VISIBLE
    }

    private fun addResult(r: Outcome) {
        val barColor = when (r.kind) {
            Kind.OK -> col(R.color.accent)
            Kind.INFO -> col(R.color.warn)
            Kind.ERR -> col(R.color.err)
        }
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(col(R.color.surface), 16, col(R.color.line))
            clipToOutline = true
            outlineProvider = ViewOutlineProvider.BACKGROUND
        }
        item.addView(View(this).apply { setBackgroundColor(barColor) }, LinearLayout.LayoutParams(dp(5), MATCH))

        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        body.addView(tv(r.title, 15f, col(R.color.ink), true))
        body.addView(tv(r.body, 14f, col(R.color.muted)), lp(2))
        r.saved?.let { body.addView(tv(it, 16f, col(R.color.saved), true), lp(6)) }
        r.note?.let { body.addView(tv(it, 13f, col(R.color.muted)), lp(4)) }
        item.addView(body, LinearLayout.LayoutParams(0, WRAP, 1f))

        emptyView.visibility = View.GONE
        resultsBox.addView(item, lp(10))
    }

    private fun addSummary(count: Int, bytes: Long) {
        val c = card()
        c.addView(tv("Total hemat ${mb(bytes)}", 17f, col(R.color.saved), true))
        c.addView(tv("dari $count file", 14f, col(R.color.muted)), lp(2))
        resultsBox.addView(c, lp(10))
    }

    // ---------- pemilihan & proses file ----------

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        startActivityForResult(i, reqPick)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqPick || resultCode != RESULT_OK || data == null) return

        val uris = mutableListOf<Uri>()
        data.clipData?.let { c -> for (k in 0 until c.itemCount) uris.add(c.getItemAt(k).uri) }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }

        val overwrite = overwriteSwitch.isChecked
        val allowGba = gbaSwitch.isChecked
        setBusy(true)
        resultsBox.removeAllViews()
        emptyView.visibility = View.GONE

        Thread {
            var total = 0L
            var okCount = 0
            for (u in uris) {
                val r = try {
                    process(u, overwrite, allowGba)
                } catch (e: Exception) {
                    val label = try { displayName(u) } catch (e2: Exception) { "File" }
                    Outcome(
                        Kind.ERR, label, "Gagal: ${e.message}", null,
                        "Jika folder ini tidak mengizinkan penulisan, matikan \"Timpa ROM asli\"."
                    )
                }
                if (r.kind == Kind.OK) {
                    total += r.bytes
                    okCount++
                }
                runOnUiThread {
                    statusView.visibility = View.GONE
                    addResult(r)
                }
            }
            runOnUiThread {
                if (okCount > 1) addSummary(okCount, total)
                setBusy(false)
            }
        }.start()
    }

    private fun mb(n: Long) = String.format("%.2f MB", n / 1048576.0)

    private fun cap(s: String) = s.replaceFirstChar { it.uppercase() }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) return it.getString(0)
        }
        return "rom.bin"
    }

    private fun process(uri: Uri, overwrite: Boolean, allowGba: Boolean): Outcome {
        val name = displayName(uri)
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext !in supported)
            return Outcome(Kind.INFO, name, "Format tidak didukung. Gunakan .3ds .cci .nds .dsi .gba atau .xci.")

        val pfd = contentResolver.openFileDescriptor(uri, if (overwrite) "rw" else "r")
            ?: return Outcome(Kind.ERR, name, "Tidak bisa membuka file.")

        return pfd.use { p ->
            val size = p.statSize
            FileInputStream(p.fileDescriptor).use { fis ->
                if (ext in slowScan) setStatus("Memeriksa $name …")
                val used = try {
                    trimmedSize(fis, size, ext, allowGba)
                } catch (s: Skip) {
                    return@use Outcome(Kind.INFO, name, cap(s.message ?: "Dilewati."))
                }
                if (used >= size)
                    return@use Outcome(Kind.INFO, name, "Sudah ter-trim (${mb(size)}).")

                val saved = size - used
                val sizes = "${mb(size)} → ${mb(used)}"
                if (overwrite) {
                    // Cukup potong ekor file: tanpa salinan, instan.
                    FileOutputStream(p.fileDescriptor).use { fos -> fos.channel.truncate(used) }
                    return@use Outcome(
                        Kind.OK, name, sizes, "Hemat ${mb(saved)}", "ROM asli sudah dipangkas.", saved
                    )
                }

                val outName = name.substringBeforeLast('.', name) + "_trimmed." + ext
                copyToDownloads(fis, used, outName)
                Outcome(
                    Kind.OK, name, sizes, "Hemat ${mb(saved)}", "Disimpan di Download/$outName", saved
                )
            }
        }
    }

    /** Ukuran ROM yang perlu dipertahankan. Melempar Skip jika file tidak aman dipangkas. */
    private fun trimmedSize(fis: FileInputStream, size: Long, ext: String, allowGba: Boolean): Long {
        val ch = fis.channel
        ch.position(0)
        val head = ByteBuffer.allocate(0x240).order(ByteOrder.LITTLE_ENDIAN)
        while (head.hasRemaining()) if (ch.read(head) < 0) break
        head.flip()
        return when (ext) {
            "xci" -> trimXci(ch, head, size)
            "3ds", "cci" -> trim3ds(ch, head, size)
            "gba" -> trimGba(ch, head, size, allowGba)
            else -> trimNds(ch, head, size)
        }
    }

    private fun trimNds(ch: FileChannel, head: ByteBuffer, size: Long): Long {
        if (head.limit() < 0x200) throw Skip("bukan ROM NDS yang valid.")
        // CRC logo Nintendo di header (0xCF56) ada di hampir semua ROM NDS.
        if (head.get(0x15C) != 0x56.toByte() || head.get(0x15D) != 0xCF.toByte())
            throw Skip("bukan ROM NDS yang valid (header tidak cocok), dilewati demi keamanan.")

        var used = head.getInt(0x80).toLong() and 0xFFFFFFFFL
        val unit = head.get(0x12).toInt()
        if ((unit and 2) != 0 && head.limit() >= 0x214) {
            val dsi = head.getInt(0x210).toLong() and 0xFFFFFFFFL
            if (dsi > used) used = dsi
        }
        // Tanda tangan RSA 0x88 byte setelah data ("ac")
        if (used > 0 && used + 2 <= size) {
            val sig = ByteBuffer.allocate(2)
            ch.read(sig, used)
            if (sig.get(0).toInt() == 0x61 && sig.get(1).toInt() == 0x63) used += 0x88
        }
        if (used <= 0x200 || used > size) used = size
        return used
    }

    private fun trim3ds(ch: FileChannel, head: ByteBuffer, size: Long): Long {
        if (head.limit() < 0x160 ||
            head.get(0x100) != 'N'.code.toByte() || head.get(0x101) != 'C'.code.toByte() ||
            head.get(0x102) != 'S'.code.toByte() || head.get(0x103) != 'D'.code.toByte()
        ) throw Skip("bukan file 3DS (CCI) yang valid.")

        // Tabel partisi NCSD: 8 entri (offset, panjang) dalam satuan 0x200 byte.
        var endUnits = 0L
        for (i in 0 until 8) {
            val off = head.getInt(0x120 + i * 8).toLong() and 0xFFFFFFFFL
            val len = head.getInt(0x124 + i * 8).toLong() and 0xFFFFFFFFL
            if (len > 0 && off + len > endUnits) endUnits = off + len
        }
        val used = endUnits * 0x200L
        if (used < 0x4000) throw Skip("header 3DS tidak masuk akal, dilewati demi keamanan.")
        if (used >= size) return size

        // Pengaman: semua byte setelah partisi terakhir harus berupa padding 0xFF.
        if (lastNonPad(ch, size, 0xFF.toByte(), used) != used)
            throw Skip("ada data setelah partisi terakhir, tidak dipangkas demi keamanan.")
        return used
    }

    private fun trimXci(ch: FileChannel, head: ByteBuffer, size: Long): Long {
        if (head.limit() < 0x120 ||
            head.get(0x100) != 'H'.code.toByte() || head.get(0x101) != 'E'.code.toByte() ||
            head.get(0x102) != 'A'.code.toByte() || head.get(0x103) != 'D'.code.toByte()
        ) throw Skip("bukan file XCI yang valid.")

        // ValidDataEndAddress (satuan 0x200 byte); +1 agar blok terakhir ikut terjaga.
        val units = head.getInt(0x118).toLong() and 0xFFFFFFFFL
        val used = (units + 1) * 0x200L
        if (used < 0x10000) throw Skip("header XCI tidak masuk akal, dilewati demi keamanan.")
        if (used >= size) return size

        // Pengaman: semua byte setelah batas harus berupa padding 0xFF.
        if (lastNonPad(ch, size, 0xFF.toByte(), used) != used)
            throw Skip("ada data setelah batas ukuran di header, tidak dipangkas demi keamanan.")
        return used
    }

    private fun trimGba(ch: FileChannel, head: ByteBuffer, size: Long, allowGba: Boolean): Long {
        if (!allowGba)
            throw Skip("GBA dilewati. Aktifkan \"Izinkan trim GBA\" jika Anda ingin memangkasnya.")
        if (size < 0xC0 || head.limit() <= 0xB2 || head.get(0xB2) != 0x96.toByte())
            throw Skip("bukan ROM GBA yang valid.")

        var used = lastNonPad(ch, size, 0xFF.toByte(), 0xC0)
        used = (used + 3) and 3L.inv() // rata ke 4 byte
        if (size - used < 0x1000) return size // padding terlalu kecil, tidak sepadan
        return used
    }

    /**
     * Posisi (indeks + 1) byte terakhir yang BUKAN [pad] dalam rentang [floor, size).
     * Mengembalikan [floor] jika seluruh rentang itu hanya berisi [pad].
     */
    private fun lastNonPad(ch: FileChannel, size: Long, pad: Byte, floor: Long): Long {
        val buf = ByteBuffer.allocate(1 shl 20)
        var end = size
        while (end > floor) {
            val start = maxOf(floor, end - buf.capacity())
            val len = (end - start).toInt()
            buf.clear()
            buf.limit(len)
            while (buf.hasRemaining()) {
                if (ch.read(buf, start + buf.position()) < 0) break
            }
            for (i in len - 1 downTo 0) {
                if (buf.get(i) != pad) return start + i + 1
            }
            end = start
        }
        return floor
    }

    private fun copyToDownloads(fis: FileInputStream, count: Long, outName: String) {
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, outName)
            put(MediaStore.Downloads.MIME_TYPE, "application/octet-stream")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val target = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("tidak bisa membuat file di Download")
        try {
            fis.channel.position(0)
            contentResolver.openOutputStream(target)!!.use { out ->
                val buf = ByteArray(1 shl 20)
                var left = count
                while (left > 0) {
                    val n = fis.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) break
                    out.write(buf, 0, n)
                    left -= n
                }
            }
            val done = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
            contentResolver.update(target, done, null, null)
        } catch (e: Exception) {
            contentResolver.delete(target, null, null)
            throw e
        }
    }
}
