# ROM Trimmer (Android)

Pemangkas ROM langsung di HP: timpa file asli atau simpan salinan.
Native Kotlin, tanpa dependensi. Ikon adaptif (vektor) dan tema terang/gelap otomatis.

Format: .3ds (.cci), .nds, .dsi, .gba, .xci (GBA perlu sakelar khusus, default mati).

## Build tanpa install apa pun (GitHub Actions)
Unggah NDSTrim-project.zip ke repositori GitHub beserta .github/workflows/build.yml.
Tab Actions > unduh artifact "NDSTrim-apk".

## Build lokal
Android Studio: File > Open > Build APK(s), atau `gradle assembleDebug` (JDK 17, SDK API 34).
