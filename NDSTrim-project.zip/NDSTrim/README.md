# NDS Trim (Android)

Pemangkas ROM Nintendo DS. Native Kotlin, tanpa dependensi, tanpa izin khusus.
Butuh Android 10 (API 29) atau lebih baru.

## Cara 1: Android Studio
1. File > Open, pilih folder NDSTrim ini.
2. Tunggu Gradle sync (setujui jika Studio menawarkan upgrade versi plugin).
3. Build > Build APK(s). Hasil: app/build/outputs/apk/debug/app-debug.apk

## Cara 2: Command line (Gradle 8.7+, JDK 17, Android SDK API 34)
    gradle assembleDebug

## Cara 3: Tanpa install apa pun (GitHub Actions)
Unggah folder ini ke repositori GitHub. Tab Actions > Build APK > unduh
artifact "NDSTrim-apk".

## Pasang di HP
Salin app-debug.apk ke HP, buka, izinkan "install dari sumber ini".
